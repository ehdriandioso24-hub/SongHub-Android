(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  function finishStartup(message) {
    const screen = $('startupScreen');
    const label = $('startupMessage');
    if (label && message) label.textContent = message;
    if (screen) {
      screen.classList.add('done');
      window.setTimeout(() => { if (screen.isConnected) screen.style.display = 'none'; }, 450);
    }
  }
  // Fail open: a slow or damaged local database must not leave the splash screen forever.
  window.setTimeout(() => {
    const screen = $('startupScreen');
    if (screen && !screen.classList.contains('done')) finishStartup('Still loading? You can try reopening SongHub.');
  }, 12000);
  let songs = [], activeFilter = 'all', activeLetter = '', sortMode = 'list';
  let current = null, rendered = 0, filtered = [], pageSize = 100, activeView = 'library', renderingMore = false;

  function readJSON(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (_) { return fallback; }
  }
  let favorites = new Set((Array.isArray(readJSON('songhub_favorites', [])) ? readJSON('songhub_favorites', []) : []).map(String));
  let lyrics = readJSON('songhub_lyrics', {});
  if (!lyrics || typeof lyrics !== 'object' || Array.isArray(lyrics)) lyrics = {};

  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const text = value => String(value ?? '').trim();
  const norm = value => text(value).toLocaleLowerCase();
  function toast(message) {
    $('toast').textContent = message;
    $('toast').style.display = 'block';
    clearTimeout(window._toastTimer);
    window._toastTimer = setTimeout(() => $('toast').style.display = 'none', 2400);
  }
  function safeStore(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch (_) { toast('Could not save: device storage may be full. Export a backup and free some space.'); return false; }
  }
  function saveFav() {
    safeStore('songhub_favorites', [...favorites]);
    $('favStat').textContent = favorites.size;
    $('favCount').textContent = favorites.size + ' saved';
  }
  function saveLyrics() { return safeStore('songhub_lyrics', lyrics); }
  function hasLyrics(song) { return typeof lyrics[song.id] === 'string' && !!lyrics[song.id].trim(); }

  async function copyText(value, successMessage) {
    const content = String(value ?? '');
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(content);
      } else {
        const helper = document.createElement('textarea');
        helper.value = content;
        helper.setAttribute('readonly', '');
        helper.style.position = 'fixed'; helper.style.opacity = '0';
        document.body.appendChild(helper); helper.select();
        const copied = document.execCommand('copy'); helper.remove();
        if (!copied) throw new Error('Clipboard unavailable');
      }
      toast(successMessage || 'Copied to clipboard');
    } catch (_) { toast('Copy was not available on this device. You can select and copy the text manually.'); }
  }

  function songCard(song) {
    const id = esc(song.id);
    const number = text(song.number) || '—';
    return `<article class="song"><button class="no number-copy" type="button" data-copy-number="${id}" aria-label="Copy song number ${esc(number)}" title="Tap to copy song number">${esc(number)}<span class="copy-hint">COPY</span></button><div data-open="${id}" class="song-main" style="min-width:0;cursor:pointer" role="button" tabindex="0" aria-label="Open ${esc(song.title || 'song')}"><div class="song-title">${esc(song.title || 'Untitled')}</div><div class="artist">${esc(song.artist || 'Unknown artist')}</div><div class="meta">${song.category ? `<span class="tag">${esc(song.category)}</span>` : ''}${song.type ? `<span class="tag">${esc(song.type)}</span>` : ''}${hasLyrics(song) ? '<span class="tag">Lyrics saved</span>' : ''}</div></div><button class="fav ${favorites.has(String(song.id)) ? 'on' : ''}" data-fav="${id}" aria-label="${favorites.has(String(song.id)) ? 'Remove from' : 'Add to'} favorites">${favorites.has(String(song.id)) ? '♥' : '♡'}</button></article>`;
  }

  function applyFilter() {
    const query = norm($('search').value);
    const searchMode = $('searchMode') ? $('searchMode').value : 'all';
    filtered = songs.filter(song => {
      if (activeFilter === 'favorites' && !favorites.has(String(song.id))) return false;
      if (activeFilter === 'lyrics' && !hasLyrics(song)) return false;
      if (activeFilter === 'Pop' && norm(song.category) !== 'pop') return false;
      if (activeFilter === 'MIDI' && norm(song.type) !== 'midi') return false;
      const title = norm(song.title), artist = norm(song.artist), number = norm(song.number);
      if (activeLetter === '#' && !/^\d/.test(title)) return false;
      if (activeLetter && activeLetter !== '#' && !title.startsWith(norm(activeLetter))) return false;
      if (!query) return true;
      if (searchMode === 'title') return title.includes(query);
      if (searchMode === 'artist') return artist.includes(query);
      if (searchMode === 'number') return number.includes(query);
      return title.includes(query) || artist.includes(query) || number.includes(query);
    });
    filtered.sort((a, b) => {
      const q = norm($('search').value);
      if (q && (!$('searchMode') || $('searchMode').value === 'all')) {
        const ap = norm(a.title).startsWith(q) ? 0 : 1;
        const bp = norm(b.title).startsWith(q) ? 0 : 1;
        if (ap !== bp) return ap - bp;
      }
      if (sortMode === 'az') return text(a.title).localeCompare(text(b.title), undefined, {sensitivity:'base'}) || text(a.artist).localeCompare(text(b.artist));
      if (sortMode === 'artist') return text(a.artist).localeCompare(text(b.artist), undefined, {sensitivity:'base'}) || text(a.title).localeCompare(text(b.title));
      if (sortMode === 'songno') return text(a.number).localeCompare(text(b.number), undefined, {numeric:true}) || text(a.title).localeCompare(text(b.title));
      return (Number(a.id) || 0) - (Number(b.id) || 0);
    });
    rendered = 0;
    $('songList').innerHTML = '';
    $('resultCount').textContent = filtered.length.toLocaleString() + ' songs';
    const letterHeading = activeLetter ? (activeLetter === '#' ? 'Songs starting with numbers' : 'Songs starting with ' + activeLetter) : '';
    $('listHeading').textContent = letterHeading || (query ? 'Search results for “' + text($('search').value) + '”' : 'All songs');
    if (!filtered.length) {
      $('songList').innerHTML = '<div class="empty">No songs found. Try another title, artist, or number.</div>';
      return;
    }
    renderMore();
  }

  function renderMore() {
    if (activeView !== 'library' || renderingMore || rendered >= filtered.length) return;
    renderingMore = true;
    try {
      const start = rendered;
      const chunk = filtered.slice(start, start + pageSize);
      if (!chunk.length && rendered === 0) {
        $('songList').innerHTML = '<div class="empty">Nothing here yet.</div>';
        return;
      }
      // Append each batch once. Never clear existing cards during scroll loading.
      $('songList').insertAdjacentHTML('beforeend', chunk.map(songCard).join(''));
      rendered = start + chunk.length;
    } finally {
      renderingMore = false;
    }
  }

  function openSong(id) {
    const song = songs.find(item => String(item.id) === String(id));
    if (!song) return;
    current = song;
    $('detailNumber').textContent = 'No. ' + (text(song.number) || '—') + ' · tap to copy';
    $('detailTitle').textContent = song.title || 'Untitled';
    $('detailArtist').textContent = song.artist || 'Unknown artist';
    $('detailMeta').innerHTML = [song.category, song.type].filter(Boolean).map(item => `<span class="tag">${esc(item)}</span>`).join('');
    $('lyricsInput').value = lyrics[song.id] || '';
    updateLyricsCount();
    $('toggleFavorite').textContent = favorites.has(String(song.id)) ? '♥ Remove favorite' : '♡ Add favorite';
    $('detailOverlay').classList.add('show');
  }
  function closeSong() { $('detailOverlay').classList.remove('show'); current = null; }
  function showView(view) {
    activeView = view;
    ['library','favorites','pdf','settings'].forEach(name => $(name + 'View').classList.toggle('hidden', name !== view));
    document.querySelectorAll('.nav-btn').forEach(button => button.classList.toggle('active', button.dataset.view === view));
    $('searchArea').classList.toggle('hidden', view !== 'library');
    if (view === 'favorites') renderFavorites();
    if (view === 'library') applyFilter();
    if (view === 'settings') $('libraryInfo').textContent = songs.length.toLocaleString() + ' songs loaded from the workbook.';
  }
  function renderFavorites() {
    $('favStat').textContent = favorites.size;
    $('favCount').textContent = favorites.size + ' saved';
    const list = songs.filter(song => favorites.has(String(song.id)));
    $('favList').innerHTML = list.length ? list.map(songCard).join('') : '<div class="empty">No favorites yet.<br>Tap ♡ beside a song to save it here.</div>';
  }
  function toggleFav(id) {
    id = String(id);
    if (favorites.has(id)) favorites.delete(id); else favorites.add(id);
    saveFav();
    if (current && String(current.id) === id) $('toggleFavorite').textContent = favorites.has(id) ? '♥ Remove favorite' : '♡ Add favorite';
    if (activeView === 'favorites') renderFavorites(); else applyFilter();
  }
  function updateLyricsCount() {
    const count = $('lyricsInput').value.length;
    $('lyricsCount').textContent = count.toLocaleString() + ' characters';
  }

  document.addEventListener('click', event => {
    const open = event.target.closest('[data-open]');
    const fav = event.target.closest('[data-fav]');
    const copyNumber = event.target.closest('[data-copy-number]');
    const nav = event.target.closest('[data-view]');
    const chip = event.target.closest('[data-filter]');
    const letter = event.target.closest('[data-letter]');
    if (copyNumber) { event.preventDefault(); event.stopPropagation(); const song = songs.find(item => String(item.id) === String(copyNumber.dataset.copyNumber)); if (song) copyText(song.number || '', 'Song number copied'); }
    if (open) openSong(open.dataset.open);
    if (fav) { event.preventDefault(); event.stopPropagation(); toggleFav(fav.dataset.fav); }
    if (nav) showView(nav.dataset.view);
    if (chip) { activeFilter = chip.dataset.filter; document.querySelectorAll('.chip').forEach(button => button.classList.toggle('active', button === chip)); applyFilter(); }
    if (letter) {
      activeLetter = activeLetter === letter.dataset.letter ? '' : letter.dataset.letter;
      $('search').value = '';
      document.querySelectorAll('.letter-btn').forEach(button => button.classList.toggle('active', button.dataset.letter === activeLetter));
      applyFilter();
    }
  });
  document.addEventListener('keydown', event => {
    const open = event.target.closest && event.target.closest('[data-open]');
    if (open && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); openSong(open.dataset.open); }
  });
  $('search').addEventListener('input', () => {
    activeLetter = '';
    document.querySelectorAll('.letter-btn').forEach(button => button.classList.remove('active'));
    applyFilter();
  });
  $('searchMode').addEventListener('change', applyFilter);
  $('clearSearch').onclick = () => { $('search').value = ''; activeLetter = ''; document.querySelectorAll('.letter-btn').forEach(button => button.classList.remove('active')); applyFilter(); };
  $('closeDetail').onclick = closeSong;
  $('detailOverlay').addEventListener('click', event => { if (event.target === $('detailOverlay')) closeSong(); });
  $('detailNumber').onclick = () => { if (current) copyText(current.number || '', 'Song number copied'); };
  $('lyricsInput').addEventListener('input', updateLyricsCount);
  $('saveLyrics').onclick = () => {
    if (!current) return;
    const value = $('lyricsInput').value;
    if (value.trim()) lyrics[current.id] = value; else delete lyrics[current.id];
    if (saveLyrics()) toast('Saved on this device for offline reading');
    closeSong();
    if (activeView === 'library') applyFilter(); else if (activeView === 'favorites') renderFavorites();
  };
  $('copyLyrics').onclick = () => copyText($('lyricsInput').value, 'Text copied');
  $('toggleFavorite').onclick = () => { if (current) toggleFav(current.id); };
  $('randomBtn').onclick = () => { if (songs.length) openSong(songs[Math.floor(Math.random() * songs.length)].id); };
  $('sortBtn').onclick = () => {
    sortMode = sortMode === 'list' ? 'az' : sortMode === 'az' ? 'artist' : sortMode === 'artist' ? 'songno' : 'list';
    $('sortBtn').textContent = sortMode === 'list' ? 'Sort: List' : sortMode === 'az' ? 'Sort: A–Z' : sortMode === 'artist' ? 'Sort: Artist' : 'Sort: Song No.';
    applyFilter();
  };
  $('pdfBtn').onclick = () => { if (window.SongHubAndroid && window.SongHubAndroid.openPrintablePdf) window.SongHubAndroid.openPrintablePdf(); else showView('pdf'); };
  $('backLibrary').onclick = () => showView('library');

  $('exportBtn').onclick = () => {
    const backup = { app: 'SongHub', version: 2, exportedAt: new Date().toISOString(), favorites: [...favorites], lyrics };
    const blob = new Blob([JSON.stringify(backup, null, 2)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a'); link.href = url; link.download = 'songhub-backup-' + new Date().toISOString().slice(0,10) + '.json';
    document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1500);
    toast('Backup exported. Keep the file somewhere safe.');
  };
  $('importFile').onchange = async event => {
    const file = event.target.files && event.target.files[0];
    if (!file) return;
    try {
      if (file.size > 10 * 1024 * 1024) throw new Error('Backup file is too large');
      const data = JSON.parse(await file.text());
      if (!data || typeof data !== 'object' || Array.isArray(data) || (!Array.isArray(data.favorites) && (!data.lyrics || typeof data.lyrics !== 'object'))) throw new Error('Invalid backup format');
      let addedFavorites = 0, addedLyrics = 0;
      if (Array.isArray(data.favorites)) for (const id of data.favorites) {
        if ((typeof id === 'string' || typeof id === 'number') && !favorites.has(String(id))) { favorites.add(String(id)); addedFavorites++; }
      }
      if (data.lyrics && typeof data.lyrics === 'object' && !Array.isArray(data.lyrics)) {
        for (const [id, value] of Object.entries(data.lyrics)) {
          if ((typeof value === 'string') && !(typeof lyrics[id] === 'string' && lyrics[id].length)) { lyrics[id] = value; addedLyrics++; }
        }
      }
      saveFav(); saveLyrics(); applyFilter();
      toast(`Backup merged: ${addedFavorites} favorites, ${addedLyrics} lyric notes added. Existing data kept.`);
    } catch (_) { toast('Could not import backup. Choose a valid SongHub JSON backup.'); }
    event.target.value = '';
  };

  // Load the next batch before the user reaches the end. The scroll fallback
  // helps Android WebView devices where IntersectionObserver can miss fast flings.
  const loadNextBatch = () => {
    if (activeView !== 'library' || rendered >= filtered.length) return;
    const sentinel = $('sentinel');
    if (!sentinel) return;
    const rect = sentinel.getBoundingClientRect();
    if (rect.top <= window.innerHeight + 900) renderMore();
  };
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      if (entries.some(entry => entry.isIntersecting)) renderMore();
    }, {rootMargin:'900px 0px'});
    observer.observe($('sentinel'));
  }
  let scrollLoadPending = false;
  window.addEventListener('scroll', () => {
    if (scrollLoadPending) return;
    scrollLoadPending = true;
    window.requestAnimationFrame(() => {
      scrollLoadPending = false;
      loadNextBatch();
    });
  }, {passive:true});
  window.addEventListener('resize', loadNextBatch, {passive:true});
  const loadSongData = window.SONGHUB_DATA ? Promise.resolve(window.SONGHUB_DATA) : fetch('songs.json').then(response => { if (!response.ok) throw new Error('Unable to load song list'); return response.json(); });
  loadSongData.then(data => {
    if (!Array.isArray(data)) throw new Error('Invalid song list');
    songs = data.filter(song => song && song.id != null);
    $('totalStat').textContent = songs.length.toLocaleString();
    saveFav();
    $('libraryInfo').textContent = songs.length.toLocaleString() + ' songs loaded from the workbook.';
    applyFilter();
    finishStartup('Your songs are ready.');
  }).catch(() => {
    $('songList').innerHTML = '<div class="empty">Could not load the song data. Reopen the app or check that songs.json is included.</div>';
    toast('Song list could not be loaded');
    finishStartup('Song list could not load. Please reopen SongHub.');
  });
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
})();
