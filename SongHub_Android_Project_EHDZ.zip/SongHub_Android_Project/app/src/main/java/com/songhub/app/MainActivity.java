package com.songhub.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle state) { super.onCreate(state); web = new WebView(this); web.setBackgroundColor(0xFF050D1A); WebSettings settings = web.getSettings(); settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setAllowFileAccess(true); settings.setAllowContentAccess(true); settings.setBuiltInZoomControls(false); settings.setDisplayZoomControls(false); web.addJavascriptInterface(new AndroidBridge(), "SongHubAndroid"); web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient()); setContentView(web); web.loadUrl("file:///android_asset/www/index.html"); }
  private class AndroidBridge {
    @JavascriptInterface public void openPrintablePdf() { runOnUiThread(() -> { try { File pdf = new File(getCacheDir(), "SongHub_Ready_to_Print_500_Page_Songbook.pdf"); try (InputStream in = getAssets().open("www/songbook.pdf"); FileOutputStream out = new FileOutputStream(pdf)) { byte[] buf = new byte[16384]; int n; while ((n = in.read(buf)) > 0) out.write(buf, 0, n); } Uri uri = FileProvider.getUriForFile(MainActivity.this, "com.songhub.app.fileprovider", pdf); Intent intent = new Intent(Intent.ACTION_VIEW); intent.setDataAndType(uri, "application/pdf"); intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(Intent.createChooser(intent, "Open SongHub printable songbook")); } catch (Exception ex) { Toast.makeText(MainActivity.this, "No PDF viewer available. You can still find the PDF inside the app project.", Toast.LENGTH_LONG).show(); } }); }
  }
  @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
