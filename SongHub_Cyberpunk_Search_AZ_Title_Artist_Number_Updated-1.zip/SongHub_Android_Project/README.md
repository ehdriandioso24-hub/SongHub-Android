# SongHub Android App (Cyberpunk Neon Dark EDITION)

An offline-first Android WebView app and installable web app built from the uploaded SongHub workbook and 500-page PDF.

## Included
- 47,998 searchable song records (number, title, artist, category, type, update) extracted from `songhub_prebuilt_songlist.xlsx`.
- The uploaded `SongHub_Ready_to_Print_500_Page_Songbook.pdf` bundled as `songbook.pdf`.
- Fast search, category/type filters, number/title sorting, random song picker, favorites, editable personal lyrics/notes saved locally, JSON backup export/import.
- Offline-first web cache for hosted/PWA usage; Android app assets are bundled for offline startup. The Android PDF button opens the bundled print PDF in an installed PDF viewer.
- Neon blue UI, cyan song-number cells, alternating white/light-gray rows.

## Build Android APK
1. Install Android Studio (current stable) and a JDK supported by Android Gradle Plugin 8.7.3.
2. Open this folder (`SongHub_Android_Project`) in Android Studio.
3. Let Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be under `app/build/outputs/apk/debug/`.

This environment did not include an Android SDK/Gradle installation, so an APK was not compiled here. The Android Studio project is included.

## Web / PWA
Serve the `app/src/main/assets/www` folder over HTTPS or localhost, then use your browser's **Install app** / **Add to Home screen** option. The service worker caches the app, JSON database, and PDF for offline use after the first successful load.

## Lyrics note
The supplied files include song listings but not lyric text. SongHub therefore provides a per-song lyrics/notes editor; anything you enter is stored locally on the device. Use only lyrics you have permission to store.

## Source data
The Excel file has 47,998 data rows and six columns. The PDF has exactly 500 pages. The original `.xls` and `.xlsx` versions were inspected and the visible records/row counts match.

## SongHub update (October 2026)
- Search can target all fields, title, artist, or song number. In All fields mode, title-prefix matches (for example, `SA`) are shown first while artist and number matches remain searchable.
- Tap a song-number badge in the list or the number in the detail screen to copy it.
- Sorting now cycles through original workbook order, A–Z, artist, and song number.
- Backup exports include a version and export date. Import merges new favorites and personal lyrics without replacing existing saved entries.
- Lyrics editor shows a live character count and retains the device-local storage behavior.
- Added safer handling for malformed local settings and incomplete song metadata.

The update changes only the web assets (`index.html` and `app.js`); the song database, PDF, Android Java bridge, Gradle configuration, and GitHub Actions workflow should remain unchanged. The Android build itself should still be run through the existing GitHub Actions workflow before distributing a replacement APK.
